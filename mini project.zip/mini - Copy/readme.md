# 🚌 Bus Ticket Booking System (Java Swing)

## 📌 Project Title
**Bus Ticket Booking System**

## 👥 Team Members
- Student 1: ____________________
- Student 2: ____________________

## 📘 Course Details
- **Course Code:** 244SECUBC201  
- **Course Name:** Object Oriented Programming Using Java  
- **Component:** Continuous Comprehensive Assessment (CCA)  
- **Course Outcome:** CO5  

---

## 📝 Problem Statement
Manual bus ticket booking systems are time-consuming and error-prone. There is a need for a simple computerized system that allows users to select seats, book tickets, and view booking details efficiently using a graphical user interface.

---

## 🎯 Objective
To design and develop a **Java-based Bus Ticket Booking System** that demonstrates:
- Object-Oriented Programming principles
- Graphical User Interface using Java Swing
- Seat selection and booking logic
- Ticket generation and display

---

## ✨ Features
- User-friendly **Java Swing GUI**
- **40-seat layout** with real-time availability
- Separate booking for **AC and Non-AC buses**
- Color-coded seats:
  - 🟩 Available seats
  - 🟥 Booked seats
- Ticket price calculation:
  - **AC Bus:** ₹500
  - **Non-AC Bus:** ₹300
- Ticket section displaying **all booked tickets**
- Clean professional UI with background colors and shadow effects
- Input validation and exception handling

---

## 🧠 Concepts Used
### Object-Oriented Programming
- **Abstraction:** Ticket abstract class
- **Inheritance:** ACTicket and NonACTicket classes
- **Polymorphism:** Ticket reference pointing to different ticket types
- **Encapsulation:** Data members and methods inside classes

### Other Java Concepts
- Java Swing (GUI)
- Event Handling
- Exception Handling
- Collections (`ArrayList`, `HashSet`)
- Layout Managers (`BorderLayout`, `GridLayout`, `GridBagLayout`)

---

## 🛠 Technologies Used
- **Programming Language:** Java  
- **GUI Framework:** Java Swing  
- **IDE:** IntelliJ IDEA / NetBeans / VS Code  
- **JDK Version:** JDK 8 or above  

---

## ▶ How to Run the Project
1. Install **JDK 8 or above**
2. Download or clone this repository
3. Open the project in any Java IDE
4. Compile the program:
   ```bash
   javac BusTicketBookingSystem.java
